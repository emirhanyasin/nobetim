package n.betim.n.betim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NöbetimApplication {

	public static void main(String[] args) {
		SpringApplication.run(NöbetimApplication.class, args);
	}
}
